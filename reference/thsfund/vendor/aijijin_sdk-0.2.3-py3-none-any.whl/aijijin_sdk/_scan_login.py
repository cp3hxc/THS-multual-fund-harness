"""SDK-owned PKCE scan-login protocol.

The browser only renders the server-provided URL. Session polling and the
one-time credential exchange always run in this Python process.
"""

from __future__ import annotations

import base64
import hashlib
import math
import secrets
import sys
import time
import webbrowser
from dataclasses import dataclass
from typing import Any, Callable, Mapping

from . import LoginError, NetworkError, ServerError, TokenError
from ._error_codes import (
    ErrorCode,
    SCAN_LOGIN_EXCHANGE_TERMINAL_CODES,
    SCAN_LOGIN_POLL_TERMINAL_CODES,
)
from ._http import DEFAULT_TIMEOUT
from ._http import post_json as _post_json
from ._login_lock import LoginLock


CREATE_PATH = "/v2/credential/scan-login/session"
POLL_PATH = "/v2/credential/scan-login/polling-status"
EXCHANGE_PATH = "/v2/credential/scan-login/exchange"
ProgressCallback = Callable[[Mapping[str, Any]], None]

# 仅由 SDK 自身行为触发的 16xx 错误码 → 面向用户的终态消息映射。
# 集中在此处便于 polling / exchange 两条路径共用。**不**包含：
# - 1602 / 1605：服务端对当前 SDK 状态的拒绝，SDK 行为无法触发，命中后
#   走 generic「状态查询被拒绝」/ 原样上抛路径；
# - 1603：用户行为触发（别的终端先扫了码），SDK 行为无法触发；
# - 1609：服务端限流，不视作 SDK 的终态。
_SCAN_LOGIN_TERMINAL_MESSAGES: dict[ErrorCode, str] = {
    ErrorCode.SCAN_LOGIN_SESSION_NOT_FOUND_OR_EXPIRED: (
        "扫码登录会话不存在或已过期，请重新登录"
    ),
    ErrorCode.SCAN_LOGIN_AUTH_PARAMS_INCONSISTENT: (
        "授权参数与已确认结果不一致，请重新登录"
    ),
    ErrorCode.SCAN_LOGIN_AUTHORIZATION_CODE_INVALID_OR_USED: (
        "授权码无效或已使用，请重新登录"
    ),
    ErrorCode.SCAN_LOGIN_PKCE_FAILED: (
        "PKCE 校验失败，请重新登录"
    ),
    ErrorCode.SCAN_LOGIN_MATCHING_CODE_INCONSISTENT: (
        "匹配码不一致，请重新登录"
    ),
}

_monotonic = time.monotonic
_sleep = time.sleep
_wall_time = time.time


def _scan_login_message(code: ErrorCode) -> str:
    """Return the user-facing terminal message for a scan-login error code.

    The lookup is exhaustive against the keys we actually handle. If a new
    handled code is added before this table is updated, the helper falls
    back to a generic message; the SCAN_LOGIN_POLL_TERMINAL_CODES /
    SCAN_LOGIN_EXCHANGE_TERMINAL_CODES sets are the single source of truth
    for what the SDK treats as terminal.
    """
    return _SCAN_LOGIN_TERMINAL_MESSAGES.get(
        code, "扫码登录被服务器拒绝，请重新登录"
    )


@dataclass(frozen=True)
class _Session:
    session_id: str
    browser_url: str
    poll_token: str
    expires_in: int
    poll_interval: float


def _base64url(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).rstrip(b"=").decode("ascii")


def generate_pkce() -> tuple[str, str]:
    """Return a local verifier and its RFC 7636 S256 challenge."""
    verifier = _base64url(secrets.token_bytes(32))
    challenge = _base64url(hashlib.sha256(verifier.encode("ascii")).digest())
    return verifier, challenge


def run_scan_login(
    base_url: str,
    *,
    device_info: str,
    device_name: str,
    client_version: str,
    timeout: int,
    progress_callback: ProgressCallback | None = None,
) -> dict[str, Any]:
    """Create, display, poll, and exchange one scan-login session."""
    if isinstance(timeout, bool) or not isinstance(timeout, int) or timeout <= 0:
        raise ValueError("timeout must be a positive integer")

    code_verifier, code_challenge = generate_pkce()
    with LoginLock() as login_lock:
        response = _post_json(
            base_url,
            CREATE_PATH,
            {
                "deviceInfo": device_info,
                "deviceName": device_name,
                "clientVersion": client_version,
                "codeChallenge": code_challenge,
                "codeChallengeMethod": "S256",
            },
        )
        session = _parse_session(response)
        _emit_progress(
            progress_callback,
            "session_created",
            expiresIn=session.expires_in,
            pollIntervalSeconds=session.poll_interval,
        )
        login_lock.update(
            session.browser_url,
            _wall_time() + float(session.expires_in),
        )
        _open_browser(session.browser_url)
        deadline = _monotonic() + min(float(timeout), float(session.expires_in))
        authorization_code = _poll_until_approved(
            base_url,
            session,
            deadline=deadline,
            clock=_monotonic,
            sleep=_sleep,
            progress_callback=progress_callback,
        )
        _emit_progress(progress_callback, "exchange_started")
        credentials = _exchange(base_url, authorization_code, code_verifier)
        _emit_progress(progress_callback, "completed")
        return credentials


def _emit_progress(
    callback: ProgressCallback | None,
    event: str,
    **details: Any,
) -> None:
    if callback is not None:
        callback({"event": event, **details})


def _parse_session(response: dict[str, Any]) -> _Session:
    """Validate a create-session response without echoing any secret value."""
    session_id = response.get("sessionId")
    browser_url = response.get("browserUrl")
    poll_token = response.get("sdkPollToken")
    expires_in = response.get("expiresIn")
    poll_interval = response.get("pollIntervalSeconds")

    strings = (session_id, browser_url, poll_token)
    if any(not isinstance(value, str) or not value for value in strings):
        raise LoginError("扫码会话响应不完整")
    if (
        isinstance(expires_in, bool)
        or not isinstance(expires_in, int)
        or expires_in <= 0
    ):
        raise LoginError("扫码会话响应不完整")
    if (
        isinstance(poll_interval, bool)
        or not isinstance(poll_interval, (int, float))
        or not math.isfinite(float(poll_interval))
        or float(poll_interval) <= 0
    ):
        raise LoginError("扫码会话响应不完整")

    return _Session(
        session_id=session_id,
        browser_url=browser_url,
        poll_token=poll_token,
        expires_in=expires_in,
        poll_interval=float(poll_interval),
    )


def _open_browser(browser_url: str) -> None:
    """Open the exact server URL, printing an interactive fallback on failure."""
    try:
        opened = webbrowser.open(browser_url)
    except Exception:
        opened = False
    if not opened:
        print(f"无法自动打开浏览器，请访问: {browser_url}", file=sys.stderr)


def _poll_until_approved(
    base_url: str,
    session: _Session,
    *,
    deadline: float,
    clock: Callable[[], float],
    sleep: Callable[[float], None],
    progress_callback: ProgressCallback | None = None,
) -> str:
    """轮询扫码登录状态直到批准 / 拒绝 / 过期 / 超时 / 终态错误。
    **网络抖动与 5xx 不再做自动退避重试**：一次失败即进入终态并提示用户稍后重试。
    CREATED / SCANNED 之间的等待时长始终使用会话创建时服务端下发的`pollIntervalSeconds`
    """
    body = {
        "sessionId": session.session_id,
        "sdkPollToken": session.poll_token,
    }

    while True:
        remaining = deadline - clock()
        if remaining <= 0:
            raise LoginError("扫码登录超时，请重新扫码")

        try:
            response = _post_json(
                base_url,
                POLL_PATH,
                body,
                timeout=min(DEFAULT_TIMEOUT, remaining),
            )
        except (NetworkError, ServerError) as error:
            # 网络异常 / 服务端 5xx：直接进入终态，告知用户状态查询失败；
            raise LoginError(
                "扫码登录状态查询失败，请稍后重试"
            ) from error
        except TokenError as error:
            code = error.code
            if (
                isinstance(code, ErrorCode)
                and code in SCAN_LOGIN_POLL_TERMINAL_CODES
            ):
                # 轮询路径上的 SDK-触发终态错误码（仅 1601：会话已废）。
                raise LoginError(_scan_login_message(code)) from error
            # 其余 16xx（1602/1603/1605/1609）以及非扫码登录的业务错误
            # 一律按 generic「状态查询被拒绝」上抛：服务端限流由 poll_interval
            # 规约频率，SDK 不额外退避；其它都是服务端对当前 SDK 状态的拒绝，
            # SDK 行为无法触发。
            raise LoginError("扫码登录状态查询被拒绝") from error

        status = response.get("status")
        _emit_progress(
            progress_callback,
            "poll_success",
            status=status,
        )
        if status == "APPROVED":
            authorization_code = response.get("authorizationCode")
            if not isinstance(authorization_code, str) or not authorization_code:
                raise LoginError("扫码登录批准响应不完整")
            return authorization_code
        if status not in ("CREATED", "SCANNED"):
            raise LoginError("扫码登录返回未知状态")

        delay = session.poll_interval
        _sleep_with_deadline(
            delay,
            deadline=deadline,
            clock=clock,
            sleep=sleep,
        )


def _sleep_with_deadline(
    delay: float,
    *,
    deadline: float,
    clock: Callable[[], float],
    sleep: Callable[[float], None],
) -> None:
    remaining = deadline - clock()
    sleep(min(float(delay), remaining))


def _exchange(
    base_url: str,
    authorization_code: str,
    code_verifier: str,
) -> dict[str, Any]:
    """Exchange once, with one confirmation retry after response loss.

    网络抖动重试只在第一次请求没拿到响应时进行；服务端业务拒绝（含扫码登录
    16xx 终态错误码）一律不再重试，直接转抛 LoginError，因为授权码可能已
    被消费、PKCE / 匹配码与本会话绑定，重试只会得到同样的错误。
    """
    body = {
        "authorizationCode": authorization_code,
        "codeVerifier": code_verifier,
    }
    try:
        response = _post_json(base_url, EXCHANGE_PATH, body)
    except NetworkError:
        try:
            response = _post_json(base_url, EXCHANGE_PATH, body)
        except Exception as error:
            raise LoginError("凭证交换结果无法确认，请重新扫码") from error
    except TokenError as error:
        code = error.code
        if (
            isinstance(code, ErrorCode)
            and code in SCAN_LOGIN_EXCHANGE_TERMINAL_CODES
        ):
            # exchange 路径上的 SDK-触发终态错误码：包括 1601（会话已废）
            # 与 1604/1606/1607/1608（authorizationCode / codeVerifier 与
            # 会话不匹配时的拒绝）。**不重试**——授权码可能已被消费、PKCE
            # 与本会话绑定，重试只会得到同样的错误。
            raise LoginError(_scan_login_message(code)) from error
        # 其余 16xx（1602/1603/1605/1609）原样上抛，让上层按业务码路由：
        # 这几个码非 SDK 行为触发，SDK 不该吞掉转为模糊的 LoginError。
        raise
    return _validate_exchange(response)


def _validate_exchange(response: dict[str, Any]) -> dict[str, Any]:
    # 必填字段缺失或非字符串/空值 → 整条响应视为不完整
    required = (
        "accessKey",
        "secretKey",
        "refreshToken",
        "deviceHash",
    )
    if any(
        not isinstance(response.get(field), str) or not response.get(field)
        for field in required
    ):
        raise LoginError("凭证交换响应不完整")
    # 可选字段：服务端允许 null（部分账号未启用 PKI）；若给了非 None 值，必须是非空字符串
    optional = ("privateKey", "publicKeyId")
    for field in optional:
        value = response.get(field)
        if value is None:
            continue
        if not isinstance(value, str) or not value:
            raise LoginError("凭证交换响应不完整")
    confirm_status = response.get("confirmStatus")
    format_version = response.get("credentialFormatVersion")
    if (
        isinstance(confirm_status, bool)
        or confirm_status != 1
        or isinstance(format_version, bool)
        or format_version != 2
    ):
        raise LoginError("凭证交换响应不完整")
    return dict(response)
