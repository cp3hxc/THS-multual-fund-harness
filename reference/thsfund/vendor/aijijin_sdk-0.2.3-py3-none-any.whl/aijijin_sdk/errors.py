"""Business-client and CLI exception types."""

from __future__ import annotations

from typing import Any, Optional

from . import AijijinError


class InputError(AijijinError):
    code = "INPUT_ERROR"


class ValidationError(AijijinError):
    code = "VALIDATION_ERROR"

    def __init__(self, message: str, field: Optional[str] = None) -> None:
        super().__init__(message)
        self.field = field


class BusinessAuthError(AijijinError):
    code = "BUSINESS_AUTH_ERROR"


class BusinessAPIError(AijijinError):
    code = "BUSINESS_API_ERROR"

    def __init__(
        self,
        message: str,
        business_code: Optional[Any] = None,
        status_code: Optional[int] = None,
    ) -> None:
        super().__init__(message)
        self.business_code = business_code
        self.status_code = status_code


class BusinessResponseError(AijijinError):
    code = "BUSINESS_RESPONSE_ERROR"
