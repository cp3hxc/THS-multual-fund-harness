"""Runtime URL configuration."""

from __future__ import annotations

import os
from typing import Mapping, Optional

DEFAULT_GATEWAY_URL = "https://trade.5ifund.com/openapi/gateway"
DEFAULT_API_BASE_URL = "https://trade.5ifund.com"


def _get_url(name: str, default: str, environ: Optional[Mapping[str, str]]) -> str:
    source = os.environ if environ is None else environ
    value = source.get(name)
    if value is None:
        return default
    value = value.strip()
    if not value:
        raise ValueError("{} must not be blank".format(name))
    if not value.startswith(("http://", "https://")):
        raise ValueError("{} must be an HTTP(S) URL".format(name))
    return value.rstrip("/")


def get_gateway_url(environ: Optional[Mapping[str, str]] = None) -> str:
    return _get_url("AIJIJIN_GATEWAY_URL", DEFAULT_GATEWAY_URL, environ)


def get_api_base_url(environ: Optional[Mapping[str, str]] = None) -> str:
    return _get_url("AIJIJIN_API_BASE_URL", DEFAULT_API_BASE_URL, environ)


def join_url(base: str, path: str) -> str:
    return base.rstrip("/") + "/" + path.lstrip("/")
