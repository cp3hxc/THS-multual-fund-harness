"""Cross-process lock for SDK scan-login sessions."""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any, Callable

from . import LoginError
from ._credentials import _default_dir


LOCK_FILENAME = "login.lock.json"
INITIAL_LOCK_TTL_SECONDS = 300.0


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if pid == os.getpid():
        return True
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


class LoginLock:
    """Exclusive JSON-file lock with stale-process and expiry recovery."""

    def __init__(
        self,
        lock_path: Path | None = None,
        *,
        clock: Callable[[], float] = time.time,
        pid_alive: Callable[[int], bool] = _pid_alive,
    ) -> None:
        self.path = lock_path or (_default_dir() / LOCK_FILENAME)
        self._clock = clock
        self._pid_alive = pid_alive
        self._pid = os.getpid()
        self._created_at = 0.0
        self._acquired = False

    def __enter__(self) -> "LoginLock":
        self.acquire()
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        self.release()

    def acquire(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        for _ in range(2):
            now = self._clock()
            record = {
                "pid": self._pid,
                "browserUrl": None,
                "createdAt": now,
                "expiresAt": now + INITIAL_LOCK_TTL_SECONDS,
            }
            try:
                fd = os.open(
                    str(self.path),
                    os.O_WRONLY | os.O_CREAT | os.O_EXCL,
                    0o600,
                )
            except FileExistsError:
                existing = self._read_record()
                if not self._is_stale(existing, now):
                    raise LoginError("另一个扫码登录正在进行")
                try:
                    self.path.unlink()
                except FileNotFoundError:
                    pass
                continue

            try:
                with os.fdopen(fd, "w", encoding="utf-8") as stream:
                    json.dump(record, stream, ensure_ascii=False)
            except Exception:
                try:
                    self.path.unlink()
                except OSError:
                    pass
                raise
            self._created_at = now
            self._acquired = True
            return

        raise LoginError("另一个扫码登录正在进行")

    def update(self, browser_url: str, expires_at: float) -> None:
        if not self._acquired:
            raise LoginError("扫码登录锁未持有")
        record = {
            "pid": self._pid,
            "browserUrl": browser_url,
            "createdAt": self._created_at,
            "expiresAt": expires_at,
        }
        tmp_path = self.path.with_name(f"{self.path.name}.{self._pid}.tmp")
        tmp_path.write_text(
            json.dumps(record, ensure_ascii=False, separators=(",", ":")),
            encoding="utf-8",
        )
        if os.name == "posix":
            os.chmod(tmp_path, 0o600)
        os.replace(tmp_path, self.path)

    def release(self) -> None:
        if not self._acquired:
            return
        self._acquired = False
        record = self._read_record()
        if isinstance(record, dict) and record.get("pid") == self._pid:
            try:
                self.path.unlink()
            except FileNotFoundError:
                pass

    def _read_record(self) -> dict[str, Any] | None:
        try:
            raw = self.path.read_text(encoding="utf-8")
            value = json.loads(raw)
        except (OSError, ValueError):
            return None
        return value if isinstance(value, dict) else None

    def _is_stale(self, record: dict[str, Any] | None, now: float) -> bool:
        if record is None:
            return True
        pid = record.get("pid")
        expires_at = record.get("expiresAt")
        if isinstance(pid, bool) or not isinstance(pid, int):
            return True
        if (
            isinstance(expires_at, bool)
            or not isinstance(expires_at, (int, float))
            or expires_at <= now
        ):
            return True
        return not self._pid_alive(pid)
