"""网关错误码枚举与解析。

所有网关错误码以整数形式出现在 CommonResponse.code 字段。
- 0 表示成功（HTTP 层已用 2xx + code==0 双重判定，不会进入 TokenError）
- 已知码通过 ErrorCode 暴露给外部代码做精确比较
- 未知码（未来网关新增的码）原样作为 int 透出，不抛
"""

from __future__ import annotations

from enum import IntEnum


class ErrorCode(IntEnum):
    # === 凭证类 (10xx) ===
    API_KEY_NOT_FOUND = 1001
    API_KEY_EXPIRED = 1002
    API_KEY_REVOKED = 1003

    # === Refresh Token (11xx) ===
    REFRESH_TOKEN_NOT_FOUND = 1101
    REFRESH_TOKEN_EXPIRED = 1102
    REFRESH_TOKEN_REVOKED = 1103
    REFRESH_TOKEN_INVALID_FORMAT = 1104

    # === Work Token (12xx) ===
    WORK_TOKEN_NOT_FOUND = 1201
    WORK_TOKEN_EXPIRED = 1202
    WORK_TOKEN_REVOKED = 1203
    WORK_TOKEN_INVALID_FORMAT = 1204

    # === Init Token (13xx) ===
    INIT_TOKEN_NOT_FOUND = 1301
    INIT_TOKEN_EXPIRED = 1302
    INIT_TOKEN_USED = 1303

    # === 签名类 (20xx) ===
    AK_SK_SIGNATURE_INVALID = 2001
    PRIVATE_KEY_SIGNATURE_INVALID = 2002
    TIMESTAMP_EXPIRED = 2003
    NONCE_USED = 2004
    SIGNATURE_ALGORITHM_UNSUPPORTED = 2005

    # === 设备类 (14xx) ===
    DEVICE_ALREADY_EXISTS = 1401
    DEVICE_NOT_FOUND = 1402
    DEVICE_QUOTA_EXCEEDED = 1403
    PENDING_DEVICE_QUOTA_EXCEEDED = 1404
    DEVICE_STATE_INVALID = 1405
    DEVICE_INFO_INVALID = 1406

    # === 权限类 (30xx) ===
    USER_HAS_CREDENTIALS = 3001
    USER_HAS_NO_CREDENTIALS = 3002
    NO_PERMISSION_FOR_CREDENTIAL = 3003
    INSUFFICIENT_PERMISSION = 3004
    PERMISSION_NOT_SIGNED = 3005

    # === 服务异常 (50xx) ===
    REDIS_CONNECTION_FAILED = 5001
    DATABASE_ERROR = 5002

    # === 扫码登录 (16xx) ===
    # 由 /v2/credential/scan-login/{polling-status,exchange} 在 HTTP 2xx 但
    # 业务失败时返回。SDK 轮询 / 凭证交换各自只处理与本路径相关的那些码
    # （见下方的 SCAN_LOGIN_POLL_TERMINAL_CODES / SCAN_LOGIN_EXCHANGE_TERMINAL_CODES）；
    # 命中其余 16xx（1602/1603/1605/1609，非 SDK 触发）视为普通业务拒绝，
    # 转抛 generic 错误文案让上层感知。
    SCAN_LOGIN_SESSION_NOT_FOUND_OR_EXPIRED = 1601
    SCAN_LOGIN_INVALID_STATE = 1602
    SCAN_LOGIN_BOUND_TO_OTHER_USER = 1603
    SCAN_LOGIN_AUTH_PARAMS_INCONSISTENT = 1604
    SCAN_LOGIN_INVALID_POLL_TOKEN = 1605
    SCAN_LOGIN_AUTHORIZATION_CODE_INVALID_OR_USED = 1606
    SCAN_LOGIN_PKCE_FAILED = 1607
    SCAN_LOGIN_MATCHING_CODE_INCONSISTENT = 1608
    SCAN_LOGIN_TOO_FREQUENT = 1609

    # === SDK 内部 sentinel (网关永不返回) ===
    # 用于"网关 200 但响应残缺"等非网关码触发的 TokenError
    MALFORMED_RESPONSE = -1

    @property
    def category(self) -> int:
        """返回分类码（千位百位归零）：1101 → 1100；-1 → -100。"""
        return (self.value // 100) * 100


def parse_error_code(value: object) -> ErrorCode | int:
    """把网关响应的 `code` 字段映射成 ErrorCode（已知）或原始 int（未知）。

    网关可能给 int 也可能给 str（防御性兼容），其他类型原样返回。
    bool 是 int 子类，先排除以避免 True/False 被当作 1/0 映射。
    """
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        try:
            return ErrorCode(value)
        except ValueError:
            return value
    if isinstance(value, str):
        try:
            n = int(value)
        except ValueError:
            return value
        try:
            return ErrorCode(n)
        except ValueError:
            return n
    return value


# RT 已失效（服务端状态问题或过期/吊销）的错误码集合。
# 命中时上层 get_work_token() 转抛 RefreshTokenExpiredError，提示用户去同花顺 App 更新 RT。
# 1104 (RT_INVALID_FORMAT) 是 RT 结构问题，语义不同，故不在集合内。
REFRESH_TOKEN_RECOVERABLE_CODES: frozenset[ErrorCode] = frozenset({
    ErrorCode.REFRESH_TOKEN_NOT_FOUND,
    ErrorCode.REFRESH_TOKEN_EXPIRED,
    ErrorCode.REFRESH_TOKEN_REVOKED,
})


# 设备信息无效（1406）：服务端拒绝当前 deviceInfo 时抛出，
# 需用户前往同花顺 App 复制新的提示词 / initToken 后重新 init()。
# 1401/1402/1403/1404/1405 属于设备状态/容量问题，不在此集合内，仍以 TokenError 抛出。
DEVICE_REINITIALIZATION_CODES: frozenset[ErrorCode] = frozenset({
    ErrorCode.DEVICE_INFO_INVALID,
})


# 扫码登录 /v2/credential/scan-login/polling-status 路径上"SDK 自身会触发的"
# 终态错误码：仅包含服务端返回「会话不存在或已过期」(1601)。命中后应停止轮询、
# 抛出 LoginError 让用户重新扫码。
#
# 其余 16xx 中：
# - 1602 INVALID_STATE / 1605 INVALID_POLL_TOKEN 属于服务端校验当前 SDK 状态
#   失败时的拒绝（如会话已被消费、poll_token 失效），由服务端在端点内部判定，
#   SDK 自身行为无法触发，按 generic 业务拒绝路径上抛。
# - 1603 BOUND_TO_OTHER_USER 是用户行为（别的终端先扫了码）触发的；SDK 行为
#   无法触发，按 generic 业务拒绝路径上抛。
# - 1609 TOO_FREQUENT 是服务端限流，不视作 SDK 的终态；SDK 不为它做退避重试
#   （server poll_interval 已经规约了频率）。
SCAN_LOGIN_POLL_TERMINAL_CODES: frozenset[ErrorCode] = frozenset({
    ErrorCode.SCAN_LOGIN_SESSION_NOT_FOUND_OR_EXPIRED,
})


# 扫码登录 /v2/credential/scan-login/exchange 路径上"SDK 自身会触发的"
# 终态错误码：包括 1601（会话已废）以及 1604 / 1606 / 1607 / 1608（exchange
# 校验 authorizationCode / codeVerifier 与会话不匹配时的拒绝）。命中后抛出
# LoginError，**不重试**——授权码可能已被消费、PKCE 与本会话绑定。
SCAN_LOGIN_EXCHANGE_TERMINAL_CODES: frozenset[ErrorCode] = frozenset({
    ErrorCode.SCAN_LOGIN_SESSION_NOT_FOUND_OR_EXPIRED,
    ErrorCode.SCAN_LOGIN_AUTH_PARAMS_INCONSISTENT,
    ErrorCode.SCAN_LOGIN_AUTHORIZATION_CODE_INVALID_OR_USED,
    ErrorCode.SCAN_LOGIN_PKCE_FAILED,
    ErrorCode.SCAN_LOGIN_MATCHING_CODE_INCONSISTENT,
})
