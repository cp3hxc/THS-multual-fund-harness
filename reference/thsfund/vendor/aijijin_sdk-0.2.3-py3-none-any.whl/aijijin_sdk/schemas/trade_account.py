"""Request schemas for virtual trade-account management."""

from .base import ACCOUNT_ID, Field, ObjectSchema, non_empty_string


TRADE_ACCOUNT_LIST_SCHEMA = ObjectSchema(
    {"generaltradeId": Field(ACCOUNT_ID, required=True)}
)
TRADE_ACCOUNT_CREATE_SCHEMA = ObjectSchema(
    {
        "generaltradeId": Field(ACCOUNT_ID, required=True),
        "strategyName": Field(non_empty_string, required=True),
    }
)
