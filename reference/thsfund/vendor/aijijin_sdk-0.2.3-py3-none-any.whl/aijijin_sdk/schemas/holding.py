"""Request schemas for holding and wallet endpoints."""

from __future__ import annotations

from .base import Field, ObjectSchema, enum_string

WALLET_HOME_SCHEMA = ObjectSchema({})
HOLDING_LIST_SCHEMA = ObjectSchema(
    {
        "shareCategory": Field(
            enum_string(("01", "02", "03", "04", "05", "06", "07")),
            required=True,
        )
    }
)
