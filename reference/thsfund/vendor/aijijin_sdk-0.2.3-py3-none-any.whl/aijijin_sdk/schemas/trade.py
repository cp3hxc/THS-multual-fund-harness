"""Request schemas for trade order query and revocation endpoints."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict

from aijijin_sdk.errors import ValidationError

from .base import (
    ACCOUNT_ID,
    Field,
    ObjectSchema,
    bounded_integer,
    enum_string,
    non_empty_string,
    regex_string,
)

DATE = regex_string(r"[0-9]{8}", "a yyyyMMdd date")
# 订单流水号：纯数字串，禁止逗号拼接多值。
APP_SHEET_SERIAL = regex_string(
    r"[0-9]+", "a numeric order serial number"
)


def _validate_order_list(body: Dict[str, Any]) -> None:
    try:
        start = datetime.strptime(body["startDate"], "%Y%m%d")
        end = datetime.strptime(body["endDate"], "%Y%m%d")
    except ValueError:
        raise ValidationError("must be a real yyyyMMdd date", "startDate/endDate")
    if start > end:
        raise ValidationError("startDate must not be after endDate", "startDate")
    if body["offset"] == 1:
        if "lastAcceptTime" in body or "lastAppSheetSerialNo" in body:
            raise ValidationError("cursor fields are only valid after page 1", "offset")
    else:
        for name in ("lastAcceptTime", "lastAppSheetSerialNo"):
            if name not in body:
                raise ValidationError("{} is required after page 1".format(name), name)


ORDER_LIST_SCHEMA = ObjectSchema(
    {
        "offset": Field(bounded_integer(1, 2147483647), required=True),
        "limit": Field(bounded_integer(1, 200), default=20),
        "startDate": Field(DATE, required=True),
        "endDate": Field(DATE, required=True),
        "opBusinessCode": Field(
            enum_string(("buy", "sell", "aip", "change", "dividend", "other", "all")),
            default="all",
        ),
        "opProductType": Field(
            enum_string(
                (
                    "demand",
                    "time",
                    "normal_fund",
                    "advanced_financing",
                    "pension",
                    "all",
                )
            ),
            default="all",
        ),
        "queryProcessing": Field(bool, required=True),
        "lastAcceptTime": Field(non_empty_string),
        "lastAppSheetSerialNo": Field(APP_SHEET_SERIAL),
    },
    cross_validate=_validate_order_list,
)
ORDER_DETAIL_SCHEMA = ObjectSchema(
    {"appSheetSerialNo": Field(APP_SHEET_SERIAL, required=True)}
)
REVOKE_SCHEMA = ObjectSchema(
    {
        "revokeAppSheetNo": Field(APP_SHEET_SERIAL, required=True),
        "transActionAccountId": Field(ACCOUNT_ID, required=True),
        # 退款来源：撤销购买类订单（020/022/039）且为银行卡购买时传 "1"，其它情况传 "0"。
        "refundSource": Field(enum_string(("0", "1")), required=True),
    }
)
