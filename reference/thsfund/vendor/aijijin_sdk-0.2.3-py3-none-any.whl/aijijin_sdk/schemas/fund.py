"""Request schemas for fund purchase and redemption endpoints."""

from __future__ import annotations

from typing import Any
from urllib.parse import urlparse

from aijijin_sdk.errors import ValidationError

from .base import (
    ACCOUNT_ID,
    Field,
    ObjectSchema,
    array_of,
    decimal_string,
    enum_string,
    non_empty_string,
    regex_string,
)

FUND_CODE = regex_string(r"[0-9]{6}", "a six-digit fund code")
# 协议留痕号：纯数字串（例 150489121945789188）。
AGREEMENT_RECORD_ID = regex_string(
    r"[0-9]+", "a numeric agreement record ID"
)
# 账户状态查询的 version：枚举式大写字母/数字/下划线（例 VOCATIONCODE_22）。
VERSION_CODE = regex_string(
    r"[A-Z0-9_]+", "an uppercase version code (letters, digits, underscores)"
)
ORDER_ID = non_empty_string


def http_url(value: Any, path: str) -> str:
    value = non_empty_string(value, path)
    parsed = urlparse(value)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise ValidationError("must be an HTTP(S) URL", path)
    return value


AGREEMENT_SCHEMA = ObjectSchema(
    {
        "title": Field(non_empty_string, required=True),
        "agreementUrl": Field(http_url, required=True),
    }
)

SUBSCRIBE_INIT_SCHEMA = ObjectSchema(
    {"fundCode": Field(FUND_CODE, required=True)}
)
FEE_RULE_SCHEMA = ObjectSchema({"fundCode": Field(FUND_CODE, required=True)})
TRADE_TREATY_SCHEMA = ObjectSchema({"fundCode": Field(FUND_CODE, required=True)})
ACCOUNT_STATUS_SCHEMA = ObjectSchema(
    {"version": Field(VERSION_CODE, required=True)}
)
TRADE_RECORD_SCHEMA = ObjectSchema(
    {
        "agreements": Field(array_of(AGREEMENT_SCHEMA, min_length=1), required=True),
        # sourceType 标识本次协议留痕的业务意图：
        #   BUY    —— 申购（任意 buyType）
        #   REDEEM —— 赎回至钱包（redemptionType=1），对应协议 sell.html
        # 银行卡赎回（redemptionType=0）目前不要求协议留痕，不需要调用本接口。
        "sourceType": Field(enum_string(("BUY", "REDEEM")), required=True),
    }
)
CHECK_BEFORE_TRADE_SCHEMA = ObjectSchema(
    {
        "applicationAmount": Field(decimal_string(positive=True), required=True),
        "fundCode": Field(FUND_CODE, required=True),
        "transactionAccountId": Field(ACCOUNT_ID, required=True),
    }
)
BUY_SCHEMA = ObjectSchema(
    {
        "buyType": Field(enum_string(("0", "1")), required=True),
        "fundCode": Field(FUND_CODE, required=True),
        "money": Field(decimal_string(positive=True), required=True),
        "transactionAccountId": Field(ACCOUNT_ID, required=True),
        "tradeId": Field(ACCOUNT_ID),
        # 协议留痕校验：每个 buy 请求需要带 AgreementRecord；外层 nullable，
        # 缺省或显式 null 等价于"未提供"，不发送给服务端。
        "extAttr": Field(
            ObjectSchema(
                {"AgreementRecord": Field(AGREEMENT_RECORD_ID, required=True)}
            ),
            nullable=True,
        ),
    }
)
REDEEM_RENDER_SCHEMA = ObjectSchema(
    {
        "transactionAccountId": Field(ACCOUNT_ID, required=True),
        "fundCode": Field(FUND_CODE, required=True),
    }
)
REDEEM_SCHEMA = ObjectSchema(
    {
        "fundCode": Field(FUND_CODE, required=True),
        "redemptionType": Field(enum_string(("0", "1")), required=True),
        "shareVol": Field(decimal_string(positive=True), required=True),
        "transActionAccountId": Field(ACCOUNT_ID, required=True),
        # 协议留痕校验：赎回至钱包（redemptionType=1）必传 AgreementRecord，
        # 由前置 `aijijin fund trade-record --json '{"sourceType":"REDEEM",...}'`
        # 服务端返回；银行卡赎回（redemptionType=0）目前不需要协议留痕。
        # 外层 nullable：缺省或显式 null 等价于「未提供」，不发送到服务端。
        "extAttr": Field(
            ObjectSchema(
                {"AgreementRecord": Field(AGREEMENT_RECORD_ID, required=True)}
            ),
            nullable=True,
        ),
    }
)
