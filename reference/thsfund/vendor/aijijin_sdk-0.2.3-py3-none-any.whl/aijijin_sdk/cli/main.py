"""Top-level CLI entry point."""

from __future__ import annotations

import argparse
import sys
import traceback
from typing import Callable, TextIO

from aijijin_sdk import (
    CredentialsFormatError,
    CredentialsNotFoundError,
    DeviceAuthorizationError,
    InitError,
    LoginError,
    NetworkError,
    RefreshTokenExpiredError,
    ServerError,
    TokenError,
)
from aijijin_sdk.errors import (
    BusinessAPIError,
    BusinessAuthError,
    BusinessResponseError,
    InputError,
    ValidationError,
)

from .output import write_error, write_success, write_success_with_update


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="aijijin")
    parser.add_argument("--format", choices=("json", "table"), default="json")
    parser.add_argument("--debug", action="store_true")
    subparsers = parser.add_subparsers(dest="group", required=True)
    from .commands import auth, fund, holding, trade, trade_account
    auth.register(subparsers)
    fund.register(subparsers)
    holding.register(subparsers)
    trade.register(subparsers)
    trade_account.register(subparsers)
    return parser


def main(argv=None, stdin=None, stdout=None, stderr=None) -> int:
    stdin = stdin or sys.stdin
    stdout = stdout or sys.stdout
    stderr = stderr or sys.stderr
    args = build_parser().parse_args(argv)
    args.stdin = stdin
    args.stderr = stderr
    return run_with_handler(
        lambda: args.handler(args),
        stdout,
        stderr,
        args.debug,
        args.format,
    )


def _exit_code(error: Exception) -> int:
    if isinstance(error, (InputError, ValidationError, ValueError)):
        return 2
    if isinstance(
        error,
        (
            BusinessAuthError,
            CredentialsFormatError,
            CredentialsNotFoundError,
            DeviceAuthorizationError,
            InitError,
            LoginError,
            RefreshTokenExpiredError,
            TokenError,
        ),
    ):
        return 3
    if isinstance(error, BusinessAPIError):
        return 4
    if isinstance(error, (BusinessResponseError, NetworkError, ServerError)):
        return 5
    return 5


def run_with_handler(
    handler: Callable[[], object],
    stdout: TextIO,
    stderr: TextIO,
    debug: bool,
    output_format: str = "json",
) -> int:
    try:
        result = handler()
    except Exception as error:
        write_error(error, stdout)
        if debug:
            traceback.print_exc(file=stderr)
        return _exit_code(error)
    if isinstance(result, tuple) and len(result) == 2:
        write_success_with_update(result, output_format, stdout)
    else:
        write_success(result, output_format, stdout)
    return 0
