"""Stable CLI output formats."""

from __future__ import annotations

import json
from typing import Any, Dict, List, TextIO


def select_table_data(data):
    if not isinstance(data, dict):
        return data
    payload = data.get("data")
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for key in ("fundPositonCombinedList", "fundPositonDetailList"):
            value = payload.get(key)
            if isinstance(value, list):
                return value
        return payload
    return data


def _write_utf8(text: str, stream: TextIO) -> None:
    reconfigure = getattr(stream, "reconfigure", None)
    if callable(reconfigure):
        try:
            reconfigure(encoding="utf-8")
            stream.write(text)
            stream.flush()
            return
        except (AttributeError, OSError, TypeError, ValueError):
            pass
    buffer = getattr(stream, "buffer", None)
    if buffer is not None:
        try:
            stream.flush()
        except (AttributeError, OSError, TypeError, ValueError):
            pass
        buffer.write(text.encode("utf-8"))
        buffer.flush()
        return
    stream.write(text)


def write_success(data: Any, output_format: str, stream: TextIO) -> None:
    if output_format == "table":
        _write_table(select_table_data(data), stream)
        return
    _write_utf8(json.dumps({"ok": True, "data": data}, ensure_ascii=False) + "\n", stream)


def write_success_with_update(result: tuple, output_format: str, stream: TextIO) -> None:
    """Write a success response that may include a top-level `update` field.

    `result` is `(data, update_or_None)`. When `update` is a non-empty dict, it
    is included as a top-level key alongside `data`. Empty dict / None /
    falsy values are omitted (so clients can rely on absence when no update).
    """
    data, update = result
    if output_format == "table":
        _write_table(select_table_data(data), stream)
        return
    body: Dict[str, Any] = {"ok": True, "data": data}
    if update:
        body["update"] = update
    _write_utf8(json.dumps(body, ensure_ascii=False) + "\n", stream)


def write_error(error: Exception, stream: TextIO) -> None:
    body: Dict[str, Any] = {
        "code": getattr(error, "code", error.__class__.__name__.upper()),
        "message": str(error),
    }
    field = getattr(error, "field", None)
    if field:
        body["field"] = field
    server_body = getattr(error, "body", None)
    if server_body:
        body["server_body"] = server_body
    _write_utf8(json.dumps({"ok": False, "error": body}, ensure_ascii=False) + "\n", stream)


def _write_table(data: Any, stream: TextIO) -> None:
    rows: List[Dict[str, Any]]
    if isinstance(data, dict):
        rows = [{"field": key, "value": value} for key, value in data.items()]
    elif isinstance(data, list) and all(isinstance(item, dict) for item in data):
        rows = data
    else:
        rows = [{"value": data}]
    columns = []
    for row in rows:
        for key in row:
            if key not in columns:
                columns.append(key)
    widths = {
        key: max(len(key), *(len(str(row.get(key, ""))) for row in rows))
        for key in columns
    }
    stream.write(" | ".join(key.ljust(widths[key]) for key in columns).rstrip() + "\n")
    stream.write("-+-".join("-" * widths[key] for key in columns) + "\n")
    for row in rows:
        stream.write(
            " | ".join(str(row.get(key, "")).ljust(widths[key]) for key in columns).rstrip()
            + "\n"
        )
