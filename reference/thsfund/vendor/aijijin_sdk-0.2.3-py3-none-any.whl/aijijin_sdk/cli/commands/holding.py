"""Holding CLI commands."""

from __future__ import annotations

from aijijin_sdk import (
    CredentialsFormatError,
    CredentialsNotFoundError,
    DeviceAuthorizationError,
    InitError,
    RefreshTokenExpiredError,
    TokenError,
)
from aijijin_sdk.client import BusinessClient
from aijijin_sdk.endpoints import ENDPOINTS
from aijijin_sdk.errors import BusinessAuthError
from aijijin_sdk.holdings.aggregate import (
    SHARE_CATEGORIES,
    aggregate,
)
from aijijin_sdk.schemas import validate_request
from aijijin_sdk.cli.input import UNSET, load_and_merge


_AUTH_ERRORS = (
    BusinessAuthError,
    CredentialsFormatError,
    CredentialsNotFoundError,
    DeviceAuthorizationError,
    InitError,
    RefreshTokenExpiredError,
    TokenError,
)


def _add_input_options(parser):
    parser.add_argument("--json-file")
    parser.add_argument("--stdin", action="store_true", dest="use_stdin")
    parser.add_argument("--json", dest="inline_json")
    parser.add_argument("--dry-run", action="store_true")


def _execute(args, name, named):
    """Public endpoint: return dict only (no update surfaced)."""
    merged = load_and_merge(
        args.json_file,
        args.use_stdin,
        args.inline_json,
        named,
        args.stdin,
    )
    request = validate_request(name, merged)
    if args.dry_run:
        return {"endpoint": name, "request": request}
    return BusinessClient().request(ENDPOINTS[name], request)


def _execute_protected(args, name, named):
    """Protected endpoint: return (payload, update) tuple."""
    merged = load_and_merge(
        args.json_file,
        args.use_stdin,
        args.inline_json,
        named,
        args.stdin,
    )
    request = validate_request(name, merged)
    if args.dry_run:
        return {"endpoint": name, "request": request}
    client = BusinessClient()
    payload = client.request(ENDPOINTS[name], request)
    return payload, client.last_update


def _run_overview(client=None, dry_run=False):
    """Fetch wallet-home + 7 shareCategory lists and return (aggregated_payload, update_or_None).

    Per-call failures are absorbed into the payload's ``fundApi.failedCategories``
    field (or ``wallet.ok=False``); only an auth-class failure from the very
    first call is propagated, since that means we cannot proceed at all.

    When ``dry_run=True``, returns ``({"endpoint": "overview", "request": {}}, None)``
    without constructing a client or making any network call.
    """
    if dry_run:
        return {"endpoint": "overview", "request": {}}, None
    client = client or BusinessClient()
    update = None
    wallet_resp = client.request(ENDPOINTS["wallet_home"], {})
    update = client.last_update
    funds_resp = {}
    for category in SHARE_CATEGORIES:
        funds_resp[category] = client.request(
            ENDPOINTS["holding_list"], {"shareCategory": category}
        )
        update = client.last_update or update
    return aggregate({"wallet": wallet_resp, "funds": funds_resp}), update


def register(subparsers):
    holding = subparsers.add_parser("holding", help="query holdings")
    commands = holding.add_subparsers(dest="holding_command", required=True)

    wallet = commands.add_parser("wallet-home")
    _add_input_options(wallet)
    wallet.set_defaults(
        handler=lambda args: _execute_protected(args, "wallet_home", {})
    )

    listing = commands.add_parser("list")
    _add_input_options(listing)
    listing.add_argument("--share-category", default=UNSET)
    listing.set_defaults(
        handler=lambda args: _execute_protected(
            args, "holding_list", {"shareCategory": args.share_category}
        )
    )

    overview = commands.add_parser(
        "overview",
        help="aggregated wallet + fund holdings + top profit/loss rankings",
    )
    _add_input_options(overview)
    overview.set_defaults(
        handler=lambda args: _run_overview(dry_run=args.dry_run)
    )
