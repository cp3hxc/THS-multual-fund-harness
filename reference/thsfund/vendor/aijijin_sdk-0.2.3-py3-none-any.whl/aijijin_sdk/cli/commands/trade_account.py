"""Virtual trade-account CLI commands used for position partitioning."""

from __future__ import annotations

from aijijin_sdk.cli.input import UNSET, load_and_merge
from aijijin_sdk.client import BusinessClient
from aijijin_sdk.endpoints import ENDPOINTS
from aijijin_sdk.schemas import validate_request


def _add_input_options(parser):
    parser.add_argument("--json-file")
    parser.add_argument("--stdin", action="store_true", dest="use_stdin")
    parser.add_argument("--json", dest="inline_json")
    parser.add_argument("--dry-run", action="store_true")


def _execute(args, endpoint_name, named):
    merged = load_and_merge(
        args.json_file,
        args.use_stdin,
        args.inline_json,
        named,
        args.stdin,
    )
    request = validate_request(endpoint_name, merged)
    if args.dry_run:
        return {"endpoint": endpoint_name, "request": request}
    client = BusinessClient()
    payload = client.request(ENDPOINTS[endpoint_name], request)
    return payload, client.last_update


def register(subparsers):
    trade_account = subparsers.add_parser(
        "trade-account",
        help="list and create virtual trade accounts for position partitioning",
        description=(
            "Virtual trade-account commands accept JSON through --json-file, "
            "--stdin, or --json; named options map to strict wire fields, and "
            "--dry-run performs no token or network access."
        ),
    )
    commands = trade_account.add_subparsers(
        dest="trade_account_command", required=True
    )

    listing = commands.add_parser(
        "list", help="list virtual accounts bound to a 600-prefixed account"
    )
    _add_input_options(listing)
    listing.add_argument("--general-trade-id", default=UNSET)
    listing.set_defaults(
        handler=lambda args: _execute(
            args,
            "trade_account_list",
            {"generaltradeId": args.general_trade_id},
        )
    )

    create = commands.add_parser(
        "create", help="create a virtual account under a 600-prefixed account"
    )
    _add_input_options(create)
    create.add_argument("--general-trade-id", default=UNSET)
    create.add_argument("--strategy-name", default=UNSET)
    create.set_defaults(
        handler=lambda args: _execute(
            args,
            "trade_account_create",
            {
                "generaltradeId": args.general_trade_id,
                "strategyName": args.strategy_name,
            },
        )
    )
