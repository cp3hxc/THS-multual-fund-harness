"""Authentication CLI commands."""

import contextlib
import io

from aijijin_sdk import (
    _update_state,
    get_work_token as sdk_get_work_token,
    init as sdk_init,
    login as sdk_login,
    set_refresh_token as sdk_set_refresh_token,
)
from aijijin_sdk.errors import InputError


def register(subparsers):
    auth = subparsers.add_parser("auth", help="manage aijijin credentials")
    commands = auth.add_subparsers(dest="auth_command", required=True)

    init_parser = commands.add_parser("init", help="initialize credentials")
    init_parser.add_argument("init_token")
    init_parser.add_argument("--path")
    init_parser.set_defaults(handler=handle_init)

    login_parser = commands.add_parser(
        "login", help="scan a QR code to authorize this device"
    )
    login_parser.add_argument("--path")
    login_parser.add_argument("--timeout", type=int, default=300)
    login_parser.add_argument("--force", action="store_true")
    login_parser.add_argument(
        "--verbose",
        action="store_true",
        help="write sanitized login progress to stderr",
    )
    login_parser.set_defaults(handler=handle_login)

    token_parser = commands.add_parser("work-token", help="print a fresh Work Token")
    token_parser.add_argument("--path")
    token_parser.set_defaults(handler=handle_work_token)

    refresh_parser = commands.add_parser("set-refresh-token", help="replace Refresh Token")
    refresh_parser.add_argument("token")
    refresh_parser.add_argument("--path")
    refresh_parser.set_defaults(handler=handle_set_refresh_token)

    dismiss_parser = commands.add_parser(
        "dismiss-update",
        help="dismiss the getworktoken update notification for a version",
        description=(
            "Record a dismissal so the CLI no longer surfaces the update notification. "
            "Default mode is 'never' (dismiss until the latest version string changes). "
            "Use --mode today to snooze for 24 hours; --clear to remove an existing entry."
        ),
    )
    dismiss_parser.add_argument("--version", required=True)
    dismiss_parser.add_argument("--mode", choices=("today", "never"), default="never")
    dismiss_parser.add_argument("--clear", action="store_true")
    dismiss_parser.add_argument("--path")
    dismiss_parser.set_defaults(handler=handle_dismiss_update)


def handle_init(args):
    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        status = sdk_init(args.init_token, path=args.path)
    return {"confirmStatus": status}


def handle_login(args):
    kwargs = {
        "path": args.path,
        "timeout": args.timeout,
        "force": args.force,
    }
    if args.verbose:
        kwargs["progress_callback"] = _login_progress_reporter(args.stderr)
    status = sdk_login(**kwargs)
    return {"confirmStatus": status}


def _login_progress_reporter(stderr):
    status_labels = {
        "CREATED": "等待扫码",
        "SCANNED": "已扫码，等待确认",
        "APPROVED": "已授权",
        "DENIED": "用户已拒绝",
        "EXPIRED": "会话已过期",
    }

    def report(progress):
        event = progress.get("event")
        if event == "session_created":
            expires_in = _format_number(progress.get("expiresIn"))
            interval = _format_number(progress.get("pollIntervalSeconds"))
            print(
                f"[login] 会话已创建：有效期 {expires_in} 秒，轮询间隔 {interval} 秒",
                file=stderr,
            )
        elif event == "poll_success":
            label = status_labels.get(progress.get("status"), "收到未知状态")
            print(f"[login] {label}", file=stderr)
        elif event == "poll_failed":
            error = progress.get("error")
            print(
                f"[login] 状态查询异常：{error}，已退出轮询",
                file=stderr,
            )
        elif event == "exchange_started":
            print("[login] 正在交换凭证", file=stderr)
        elif event == "completed":
            print("[login] 登录完成", file=stderr)

    return report


def _format_number(value):
    return f"{float(value):g}"


def handle_work_token(args):
    return {"workToken": sdk_get_work_token(path=args.path)}


def handle_set_refresh_token(args):
    sdk_set_refresh_token(args.token, path=args.path)
    return {"updated": True}


def handle_dismiss_update(args):
    if args.clear and args.mode != "never":
        raise InputError("--clear and --mode are mutually exclusive")
    if args.clear:
        cleared = _update_state.clear(args.version, path=args.path)
        return {"version": args.version, "cleared": cleared}
    if args.mode not in ("today", "never"):
        raise InputError("--mode must be 'today' or 'never'")
    entry = _update_state.dismiss(args.version, args.mode, path=args.path)
    out = {"version": args.version, "mode": entry["mode"]}
    if "snooze_until" in entry:
        out["snoozeUntil"] = entry["snooze_until"]
    return out
