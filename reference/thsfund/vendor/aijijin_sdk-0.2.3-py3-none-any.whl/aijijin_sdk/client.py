"""HTTP client for fund business APIs."""

from __future__ import annotations

import json
from typing import Any, Callable, Dict, Optional

import requests

from . import NetworkError, ServerError, _acquire_work_token_internal, get_work_token
from . import _update_state
from .config import DEFAULT_API_BASE_URL, get_api_base_url, join_url
from .endpoints import Endpoint
from .errors import BusinessAPIError, BusinessAuthError, BusinessResponseError

DEFAULT_TIMEOUT = 10.0


class BusinessClient:
    def __init__(
        self,
        api_base_url: Optional[str] = None,
        token_provider: Callable[[], str] = get_work_token,
        session: Optional[requests.Session] = None,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        if api_base_url is not None:
            self.api_base_url = api_base_url
            self._business_base_overridden = True
        else:
            configured_api_base_url = get_api_base_url()
            self.api_base_url = configured_api_base_url
            self._business_base_overridden = (
                configured_api_base_url != DEFAULT_API_BASE_URL
            )
        self._token_provider = token_provider
        # 区分默认与显式注入：默认走 _acquire_work_token_internal() 拿 update；
        # 显式注入（测试）→ 视为 str-only provider，update 永远 None。
        self._explicit_token_provider = token_provider is not get_work_token
        self.session = session or requests.Session()
        self.timeout = timeout
        self.last_update: Optional[Dict[str, Any]] = None

    def _acquire_token_with_update(self) -> tuple[Optional[str], Optional[Dict[str, Any]]]:
        """Return (work_token_or_None, update_or_None).

        公共接口调用者不需要 token；调用方负责先判断 endpoint.protected。
        """
        if self._explicit_token_provider:
            return self._token_provider(), None
        wt, _rt, update = _acquire_work_token_internal()
        return wt, update

    @staticmethod
    def _filter_update(raw_update: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """Apply dismiss filter; return None if dismissed."""
        if raw_update is None:
            return None
        latest = raw_update.get("latestVersion")
        if not isinstance(latest, str):
            return raw_update
        if _update_state.is_dismissed(latest):
            return None
        return raw_update

    def request(self, endpoint: Endpoint, data: Dict[str, Any]) -> Dict[str, Any]:
        if not endpoint.protected:
            self.last_update = None
            response = self._request_once(endpoint, data, None)
        else:
            token, raw_update = self._acquire_token_with_update()
            self.last_update = self._filter_update(raw_update)
            response = self._request_once(endpoint, data, token)
            if response.status_code == 401 and endpoint.replay_policy == "http_401":
                token, raw_update = self._acquire_token_with_update()
                self.last_update = self._filter_update(raw_update)
                response = self._request_once(endpoint, data, token)
        if response.status_code == 401:
            raise BusinessAuthError("business API authentication failed")
        if response.status_code >= 500:
            body = self._safe_response_text(response)
            raise ServerError(
                "business API returned HTTP {}".format(response.status_code),
                status_code=response.status_code,
                body=body,
            )
        payload = self._parse_json(response)
        if response.status_code >= 400:
            raise BusinessAPIError(
                self._message(payload, "business API returned HTTP {}".format(response.status_code)),
                status_code=response.status_code,
            )
        self._raise_business_error(payload)
        return payload

    def _request_once(
        self, endpoint: Endpoint, data: Dict[str, Any], token: Optional[str]
    ) -> requests.Response:
        if endpoint.protected and self._business_base_overridden:
            base = self.api_base_url
        else:
            base = endpoint.absolute_base or self.api_base_url
        path = endpoint.path
        if endpoint.encoding == "path":
            path = path.format(**data)
        url = join_url(base, path)
        headers = {}
        if token is not None:
            headers["Authorization"] = "Bearer " + token
        kwargs = {"headers": headers, "timeout": self.timeout}
        if endpoint.encoding == "query":
            kwargs["params"] = data
        elif endpoint.encoding == "json":
            kwargs["json"] = data
        elif endpoint.encoding == "form":
            kwargs["data"] = self._encode_form_data(data)
        try:
            return self.session.request(endpoint.method, url, **kwargs)
        except requests.RequestException as exc:
            raise NetworkError("business API request failed", cause=exc) from exc

    @staticmethod
    def _encode_form_data(data: Dict[str, Any]) -> Dict[str, Any]:
        """requests 表单编码不接受嵌套 dict；把 dict 值 JSON-encode 成字符串。

        例如 extAttr: {"AgreementRecord": "150..."} → extAttr: '{"AgreementRecord":"150..."}'。
        其余标量字段原样透传。

        注：0.2.2 时代用于 redeem 端点，但 redeem 的 Java setter `setExtAttr`
        实际期望 Map/嵌套对象而非 String，form 编码下会被 Dubbo 反序列化为
        String 后类型不匹配；redeem 已统一改为 json 编码（与 buy 一致），
        该 helper 现作为防御性兜底保留，不再被任何 endpoint 调用。
        """
        encoded: Dict[str, Any] = {}
        for key, value in data.items():
            if isinstance(value, dict):
                encoded[key] = json.dumps(value, ensure_ascii=False)
            else:
                encoded[key] = value
        return encoded

    @staticmethod
    def _safe_response_text(response: requests.Response, max_chars: int = 2048) -> Optional[str]:
        """Best-effort extract of the 5xx response body as text.

        5xx 时服务端可能附 JSON 错误体 / 文本错误 / HTML 错误页；本方法不抛异常，
        只返回字符串（截断到 max_chars）。二进制或读取失败时返回 None，避免在
        已经 5xx 的路径上又抛新的异常覆盖原始错误。
        """
        try:
            text = response.text
        except Exception:
            return None
        if not text:
            return None
        if len(text) > max_chars:
            return text[:max_chars] + "...(truncated)"
        return text

    @staticmethod
    def _parse_json(response: requests.Response) -> Dict[str, Any]:
        try:
            payload = response.json()
        except ValueError as exc:
            raise BusinessResponseError("business API returned invalid JSON") from exc
        if not isinstance(payload, dict):
            raise BusinessResponseError("business API response must be a JSON object")
        return payload

    @classmethod
    def _raise_business_error(cls, payload: Dict[str, Any]) -> None:
        status_code = payload.get("status_code")
        if status_code not in (None, 0, "0", "0000"):
            raise BusinessAPIError(
                cls._message(payload, "business request failed"),
                business_code=status_code,
            )
        error = payload.get("error")
        if isinstance(error, dict) and error.get("id") not in (None, 0, "0"):
            raise BusinessAPIError(
                cls._message(payload, "business request failed"),
                business_code=error.get("id"),
            )

    @staticmethod
    def _message(payload: Dict[str, Any], default: str) -> str:
        error = payload.get("error")
        candidates = [
            payload.get("status_msg"),
            payload.get("message"),
            error.get("msg") if isinstance(error, dict) else None,
        ]
        return next((str(value) for value in candidates if value), default)
