"""Declarative business endpoint registry."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional


@dataclass(frozen=True)
class Endpoint:
    name: str
    method: str
    path: str
    encoding: str
    protected: bool
    replay_policy: str = "never"
    absolute_base: Optional[str] = None


ENDPOINTS: Dict[str, Endpoint] = {
    "wallet_home": Endpoint("wallet_home", "GET", "/openapi/v1/query_wallet_home", "none", True, "http_401"),
    "holding_list": Endpoint("holding_list", "POST", "/openapi/holdposition/v2/ai/list", "json", True, "http_401"),
    "subscribe_init": Endpoint("subscribe_init", "POST", "/openapi/ai/subscribe/init", "query", True, "http_401"),
    "fee_rule": Endpoint("fee_rule", "GET", "/openapi/interface/fund/tradeRule/{fundCode}", "path", True, "http_401"),
    "trade_treaty": Endpoint("trade_treaty", "GET", "/openapi/interface/fund/detail/{fundCode}_tradeInitTreaty", "path", True, "http_401"),
    "account_status": Endpoint("account_status", "POST", "/openapi/rz/account/dubbo/accountInfo/getCustAccoStatus", "json", True, "http_401"),
    "trade_record": Endpoint("trade_record", "POST", "/openapi/record/trade", "json", True, "http_401"),
    "check_before_trade": Endpoint("check_before_trade", "POST", "/openapi/ai/sign_contract/v1/check_before_trade", "json", True, "http_401"),
    "buy": Endpoint("buy", "POST", "/openapi/ai/buy", "json", True, "http_401"),
    "trade_account_create": Endpoint(
        "trade_account_create",
        "POST",
        "/openapi/ai/tradeaccount/create",
        "json",
        True,
        "never",
    ),
    "trade_account_list": Endpoint(
        "trade_account_list",
        "POST",
        "/openapi/ai/tradeaccount/list",
        "json",
        True,
        "http_401",
    ),
    "redeem_render": Endpoint("redeem_render", "POST", "/openapi/ai/redemption/v1/render", "json", True, "http_401"),
    "redeem": Endpoint("redeem", "POST", "/openapi/ai/redemption/v2/redeem", "json", True, "http_401"),
    "order_list": Endpoint("order_list", "POST", "/openapi/order/v2/ai/orderlist", "json", True, "http_401"),
    "order_detail": Endpoint("order_detail", "POST", "/openapi/order/v2/ai/detail", "json", True, "http_401"),
    "revoke": Endpoint("revoke", "POST", "/openapi/ai/revoke", "json", True, "http_401"),
}
